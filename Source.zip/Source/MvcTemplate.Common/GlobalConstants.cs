﻿namespace ChillZone.Common
{
    public class GlobalConstants
    {
        public const string AdministratorRoleName = "Administrator";
        public const string PublicRoleName = "Public";
    }
}
