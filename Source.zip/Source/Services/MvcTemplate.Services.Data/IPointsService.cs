﻿namespace ChillZone.Services.Data
{
    using MvcTemplate.Data.Models;

    public interface IPointsService
    {
        Point Add(Point content);
    }
}
